const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient(); // Create DynamoDB DocumentClient instance
const s3 = new AWS.S3(); // Create S3 instance
const sns = new AWS.SNS(); // Create SNS instance
const { v4: uuidv4 } = require('uuid'); // Import uuidv4 for generating UUIDs
const validator = require('validator'); // Import validator for input validation
const jwt = require('jsonwebtoken'); // Import jsonwebtoken for JWT operations
const bcrypt = require('bcryptjs'); // Import bcryptjs for password hashing

const JWT_SECRET = "worldscookbook-123"; // JWT secret key
const S3_BUCKET = "worldscookbook-s3"; // S3 bucket name
const PLACEHOLDER_IMAGE_URL = "https://worldscookbook-s3.s3.amazonaws.com/chef.png"; // Placeholder image URL

const SNS_TOPIC_NAME = "UserRegistrationTopic"; // Replace with your SNS topic name
const REGION = "us-east-1"; // Replace with your AWS region
const ACCOUNT_ID = "733907053896"; // Replace with your AWS account ID

// Retrieve Topic ARN
let topicArn;

async function getTopicArn() {
    try {
        const createTopicParams = {
            Name: SNS_TOPIC_NAME,
        };
        const topicData = await sns.createTopic(createTopicParams).promise();
        topicArn = topicData.TopicArn;
    } catch (error) {
        console.error("Error creating/retrieving SNS topic:", error);
        throw new Error("Could not create/retrieve SNS topic");
    }
}

// Lambda function handler
exports.handler = async (event) => {
    // Ensure Topic ARN is retrieved before handling requests
    if (!topicArn) {
        await getTopicArn();
    }

    let body;
    let response;

    try {
        switch (event.routeKey) {
            // Handle user registration request
            case 'POST /register':
                body = JSON.parse(event.body); // Parse request body

                // Check required fields
                const requiredFields = ['email', 'password', 'username'];
                for (const field of requiredFields) {
                    if (!body[field]) {
                        return {
                            statusCode: 400,
                            body: JSON.stringify({ "message": `${field} is missing` })
                        };
                    }
                }

                // Validate email format
                if (!validator.isEmail(body.email)) {
                    return {
                        statusCode: 400,
                        body: JSON.stringify({ "message": "Incorrect email format" })
                    };
                }

                // Query DynamoDB to check if email already exists
                const emailParams = {
                    TableName: 'Worlds_cookbook_users',
                    IndexName: 'email-index',
                    KeyConditionExpression: 'email = :email',
                    ExpressionAttributeValues: {
                        ':email': body.email
                    },
                };

                const emailCheck = await dynamo.query(emailParams).promise();
                if (emailCheck.Items.length > 0) {
                    return {
                        statusCode: 400,
                        body: JSON.stringify({ "message": "Email is already used" })
                    };
                }

                // Generate UUID for user ID
                const userId = uuidv4();
                body.userId = userId;

                // Set default profile image URL or upload custom image to S3
                let profileImageUrl = PLACEHOLDER_IMAGE_URL;
                if (body.profileImage) {
                    const base64Image = body.profileImage.replace(/^data:image\/\w+;base64,/, '');
                    const imageBuffer = Buffer.from(base64Image, 'base64');

                    const mimeType = body.profileImage.match(/data:image\/(\w+);base64,/)[1];
                    let fileExtension;
                    switch (mimeType) {
                        case 'jpeg':
                        case 'jpg':
                            fileExtension = 'jpg';
                            break;
                        case 'png':
                            fileExtension = 'png';
                            break;
                        default:
                            return {
                                statusCode: 400,
                                body: JSON.stringify({ "message": "Unsupported image format" })
                            };
                    }

                    const uploadParams = {
                        Bucket: S3_BUCKET,
                        Key: `${userId}.${fileExtension}`,
                        Body: imageBuffer,
                        ContentType: `image/${mimeType}`
                    };

                    const uploadResult = await s3.upload(uploadParams).promise();
                    profileImageUrl = uploadResult.Location;
                }
                body.profileImageUrl = profileImageUrl;

                delete body.profileImage; // Remove profileImage from body

                // Hash password using bcrypt
                const hashedPassword = await bcrypt.hash(body.password, 10);
                body.password = hashedPassword;

                // Store user data in DynamoDB
                const params = {
                    TableName: 'Worlds_cookbook_users',
                    Item: body
                };
                await dynamo.put(params).promise();

                // Subscribe user to SNS topic for email notifications
                try {
                    const subscribeParams = {
                        Protocol: 'email',
                        TopicArn: topicArn,
                        Endpoint: body.email,
                    };
                    await sns.subscribe(subscribeParams).promise();
                } catch (error) {
                    console.error("Error subscribing user to SNS topic:", error);
                    // Handle SNS errors appropriately
                }

                // Return success response
                return {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "User registered successfully", "userId": userId })
                };

            // Handle user login request
            case 'POST /user-login':
                body = JSON.parse(event.body); // Parse request body

                // Check for required email and password fields
                if (!body.email || !body.password) {
                    return {
                        statusCode: 400,
                        body: JSON.stringify({ "message": "Email and password are required" })
                    };
                }

                // Query DynamoDB for user with given email
                const loginParams = {
                    TableName: 'Worlds_cookbook_users',
                    IndexName: 'email-index',
                    KeyConditionExpression: 'email = :email',
                    ExpressionAttributeValues: {
                        ':email': body.email
                    },
                };

                const loginResult = await dynamo.query(loginParams).promise();
                if (loginResult.Items.length === 0) {
                    return {
                        statusCode: 401,
                        body: JSON.stringify({ "message": "Invalid email or password" })
                    };
                }

                // Validate password
                const user = loginResult.Items[0];
                const isPasswordValid = await bcrypt.compare(body.password, user.password);
                if (!isPasswordValid) {
                    return {
                        statusCode: 401,
                        body: JSON.stringify({ "message": "Invalid email or password" })
                    };
                }

                // Generate JWT token for authentication
                const loginToken = jwt.sign({ userId: user.userId, email: user.email }, JWT_SECRET, { expiresIn: '1h' });

                // Send login notification via SNS
                try {
                    const snsParams = {
                        Message: `You have logged into your WorldsCookbook account.`,
                        Subject: "Login Notification",
                        TopicArn: topicArn,
                    };
                    await sns.publish(snsParams).promise();
                } catch (error) {
                    console.error("Error publishing SNS message:", error);
                    // Handle SNS publish errors appropriately
                }

                // Return success response with JWT token
                return {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "Login successful", "token": loginToken, "userId": user.userId })
                };

            // Handle get user
            case 'GET /user/{userId}':
                try {
                    const getParams = {
                        TableName: 'Worlds_cookbook_users',
                        Key: {
                            'userId': event.pathParameters.userId,
                        },
                    };

                    const getResult = await dynamo.get(getParams).promise();

                    if (!getResult.Item) {
                        return {
                            statusCode: 404,
                            body: JSON.stringify({ "message": "User not found" }),
                        };
                    }

                    return {
                        statusCode: 200,
                        body: JSON.stringify(getResult.Item),
                    };
                } catch (error) {
                    console.error("Error retrieving user:", error);
                    return {
                        statusCode: 500,
                        body: JSON.stringify({ "message": "Internal Server Error", "error": error.message }),
                    };
                }


            // Handle user profile update request
            case 'PUT /user/{userId}':
                body = JSON.parse(event.body); // Parse request body

                // Check for required fields for update, except password
                const updateFields = ['email', 'username'];
                for (const field of updateFields) {
                    if (!body[field]) {
                        return {
                            statusCode: 400,
                            body: JSON.stringify({ "message": `${field} is missing` })
                        };
                    }
                }

                // Validate email format
                if (!validator.isEmail(body.email)) {
                    return {
                        statusCode: 400,
                        body: JSON.stringify({ "message": "Incorrect email format" })
                    };
                }

                // Retrieve current user data to get the existing profile image URL
                const getUserParams = {
                    TableName: 'Worlds_cookbook_users',
                    Key: {
                        'userId': event.pathParameters.userId,
                    },
                };

                const getResult = await dynamo.get(getUserParams).promise();
                if (!getResult.Item) {
                    return {
                        statusCode: 404,
                        body: JSON.stringify({ "message": "User not found" }),
                    };
                }

                const existingUser = getResult.Item;
                let updatedProfileImageUrl = existingUser.profileImageUrl;

                // Update profile image if a new one is provided
                if (body.profileImage) {
                    const base64Image = body.profileImage.replace(/^data:image\/\w+;base64,/, '');
                    const imageBuffer = Buffer.from(base64Image, 'base64');

                    const mimeType = body.profileImage.match(/data:image\/(\w+);base64,/)[1];
                    let fileExtension;
                    switch (mimeType) {
                        case 'jpeg':
                        case 'jpg':
                            fileExtension = 'jpg';
                            break;
                        case 'png':
                            fileExtension = 'png';
                            break;
                        default:
                            return {
                                statusCode: 400,
                                body: JSON.stringify({ "message": "Unsupported image format" })
                            };
                    }

                    const uploadParams = {
                        Bucket: S3_BUCKET,
                        Key: `${event.pathParameters.userId}.${fileExtension}`,
                        Body: imageBuffer,
                        ContentType: `image/${mimeType}`
                    };

                    const uploadResult = await s3.upload(uploadParams).promise();
                    updatedProfileImageUrl = uploadResult.Location;
                }

                // Hash password if provided
                let updatedPassword = existingUser.password;
                if (body.password) {
                    updatedPassword = await bcrypt.hash(body.password, 10);
                }

                // Update user data in DynamoDB
                const updateParams = {
                    TableName: 'Worlds_cookbook_users',
                    Key: {
                        'userId': event.pathParameters.userId,
                    },
                    UpdateExpression: 'set email = :email, username = :username, profileImageUrl = :profileImageUrl, password = :password',
                    ExpressionAttributeValues: {
                        ':email': body.email,
                        ':username': body.username,
                        ':profileImageUrl': updatedProfileImageUrl,
                        ':password': updatedPassword,
                    },
                    ReturnValues: 'ALL_NEW'
                };

                const updateResult = await dynamo.update(updateParams).promise();

                // Return success response with updated user data
                return {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "User updated successfully", "user": updateResult.Attributes })
                };

            // Handle user deletion request
            case 'DELETE /user/{userId}':
                // Delete user data from DynamoDB
                const deleteParams = {
                    TableName: 'Worlds_cookbook_users',
                    Key: {
                        'userId': event.pathParameters.userId,
                    },
                };

                await dynamo.delete(deleteParams).promise();

                // Return success response
                return {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "User deleted successfully" })
                };

            default:
                response = {
                    statusCode: 400,
                    body: JSON.stringify({ message: "Invalid request" }),
                };
                break;
        }
    } catch (error) {
        console.error("Error processing request:", error);
        response = {
            statusCode: 500,
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    }

    return response;
};
