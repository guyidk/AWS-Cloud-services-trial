const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');

const S3_BUCKET = "worldscookbook-s3";
const JWT_SECRET = "worldscookbook-123"; // Ensure this matches the secret used in the users lambda

// Function to verify JWT
const verifyToken = (token) => {
    return new Promise((resolve, reject) => {
        jwt.verify(token, JWT_SECRET, (err, decoded) => {
            if (err) {
                return reject(err);
            }
            resolve(decoded);
        });
    });
};

exports.handler = async (event, context, callback) => {
    console.log("Received event:", JSON.stringify(event, null, 2));

    let body;
    let response;

    // Extract the token
    const token = event.headers.Authorization || event.headers.authorization;

    // Function to handle unauthorized response
    const unauthorizedResponse = () => ({
        statusCode: 401,
        body: JSON.stringify({ "message": "Authorization token is required" })
    });

    // Function to handle internal server error response
    const internalServerErrorResponse = (error) => ({
        statusCode: 500,
        body: JSON.stringify({ "message": "Internal Server Error", "error": error.message })
    });

    try {
        // Routes that require authorization
        const authorizedRoutes = ['POST /recipe', 'PUT /recipe/{RecipeId}', 'DELETE /recipe/{RecipeId}'];

        if (authorizedRoutes.includes(event.routeKey)) {
            if (!token) {
                response = unauthorizedResponse();
                return callback(null, response);
            }

            // Verify token
            await verifyToken(token.replace('Bearer ', ''));
        }

        // Proceed with the original logic
        const requiredFields = ['category', 'ingredients', 'instructions', 'recipename'];

        switch (event.routeKey) {
            case 'POST /recipe':
                body = JSON.parse(event.body);

                // Validate required fields
                for (const field of requiredFields) {
                    if (!body[field]) {
                        response = {
                            statusCode: 400,
                            body: JSON.stringify({ "message": `${field} is missing` })
                        };
                        return callback(null, response);
                    }
                }

                // Generate a unique UUID for RecipeId
                const RecipeId = uuidv4();
                body.RecipeId = RecipeId; // Assign generated UUID to RecipeId
                body.likes = 0; // Initialize likes to 0

                // Handle recipe image upload
                if (body.recipeImage) {
                    // Strip off the data URI scheme prefix if present
                    const base64Image = body.recipeImage.replace(/^data:image\/\w+;base64,/, '');
                    const imageBuffer = Buffer.from(base64Image, 'base64');

                    const uploadParams = {
                        Bucket: S3_BUCKET,
                        Key: `${RecipeId}.png`,
                        Body: imageBuffer,
                        ContentType: 'image/png' // Set the correct content type
                    };

                    const uploadResult = await s3.upload(uploadParams).promise();
                    body.recipeImageUrl = uploadResult.Location;
                }

                // Remove the recipeImage field from the body before saving
                delete body.recipeImage;

                const params = {
                    TableName: 'recipes',
                    Item: body
                };
                await dynamo.put(params).promise();

                response = {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "Recipe added successfully", "RecipeId": RecipeId })
                };
                return callback(null, response);

            case 'GET /recipe/{RecipeId}':
                const getRecipeParams = {
                    TableName: 'recipes',
                    KeyConditionExpression: 'RecipeId = :RecipeId',
                    ExpressionAttributeValues: {
                        ':RecipeId': event.pathParameters.RecipeId,
                    },
                };

                const getRecipeResult = await dynamo.query(getRecipeParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify(getRecipeResult.Items)
                };
                return callback(null, response);

            case 'GET /recipes/{userId}': // New case for fetching recipes by userId
                const userId = event.pathParameters.userId;

                console.log("Fetching recipes for userId:", userId); // Logging userId
                
                const userRecipesParams = {
                    TableName: 'recipes',
                    IndexName: 'userId-index', // Name of the GSI
                    KeyConditionExpression: 'userId = :userId',
                    ExpressionAttributeValues: {
                        ':userId': userId,
                    },
                };

                console.log("Query params:", JSON.stringify(userRecipesParams, null, 2)); // Logging query parameters

                const userRecipesResult = await dynamo.query(userRecipesParams).promise();

                console.log("Query result:", JSON.stringify(userRecipesResult, null, 2)); // Logging query result
                
                response = {
                    statusCode: 200,
                    body: JSON.stringify(userRecipesResult.Items)
                };
                return callback(null, response);

            case 'PUT /recipe/{RecipeId}':
                body = JSON.parse(event.body);

                // Validate required fields
                for (const field of requiredFields) {
                    if (!body[field]) {
                        response = {
                            statusCode: 400,
                            body: JSON.stringify({ "message": `${field} is missing` })
                        };
                        return callback(null, response);
                    }
                }

                // Fetch the current recipe to preserve existing image URL if not being updated
                const currentRecipeParams = {
                    TableName: 'recipes',
                    Key: { "RecipeId": event.pathParameters.RecipeId }
                };
                const currentRecipe = await dynamo.get(currentRecipeParams).promise();

                let newRecipeImageUrl = currentRecipe.Item.recipeImageUrl;
                if (body.recipeImage) {
                    // Strip off the data URI scheme prefix if present
                    const base64Image = body.recipeImage.replace(/^data:image\/\w+;base64,/, '');
                    const imageBuffer = Buffer.from(base64Image, 'base64');

                    const uploadParams = {
                        Bucket: S3_BUCKET,
                        Key: `${event.pathParameters.RecipeId}.png`,
                        Body: imageBuffer,
                        ContentType: 'image/png' // Set the correct content type
                    };

                    const uploadResult = await s3.upload(uploadParams).promise();
                    newRecipeImageUrl = uploadResult.Location;
                }

                const updateParams = {
                    TableName: 'recipes',
                    Key: { "RecipeId": event.pathParameters.RecipeId },
                    UpdateExpression: "set category = :category, ingredients = :ingredients, instructions = :instructions, recipename = :recipename, recipeImageUrl = :recipeImageUrl",
                    ExpressionAttributeValues: {
                        ":category": body.category,
                        ":ingredients": body.ingredients,
                        ":instructions": body.instructions,
                        ":recipename": body.recipename,
                        ":recipeImageUrl": newRecipeImageUrl
                    },
                };

                // Remove the recipeImage field from the body before saving
                delete body.recipeImage;

                await dynamo.update(updateParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "Recipe edited successfully" })
                };
                return callback(null, response);

            case 'DELETE /recipe/{RecipeId}':
                const deleteParams = {
                    TableName: 'recipes',
                    Key: {
                        'RecipeId': event.pathParameters.RecipeId,
                    },
                };

                await dynamo.delete(deleteParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify({ "message": "Recipe deleted successfully" })
                };
                return callback(null, response);

            case 'GET /recipes':
                const scanParams = {
                    TableName: 'recipes',
                };
                const scanResult = await dynamo.scan(scanParams).promise();
                response = {
                    statusCode: 200,
                    body: JSON.stringify(scanResult.Items)
                };
                return callback(null, response);

            default:
                response = {
                    statusCode: 400,
                    body: JSON.stringify({ "message": "Unsupported route: " + event.routeKey })
                };
                return callback(null, response);
        }
    } catch (error) {
        console.error("Error: ", error); // Log the error details
        response = internalServerErrorResponse(error);
        return callback(null, response);
    }
};
